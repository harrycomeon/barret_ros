^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rqt_bhand
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2015-07-29)
------------------
* rqt_bhand: Adding new rosrun dependency
* Preparing changelog
* Adding queue_size to publisher
* Modifying .gitignore, CMakelist to install the packages, removing .pyc files
* Modifying .gitignore, CMakelist to install the packages, removing .pyc files
* Indigo supported packages
* Adding changelog files
* Updating package.xml files
* Updating packages.xml config files
* Adding initial structure
* Contributors: Elena Gambaro, RobotnikRoman, RomanRobotnik
